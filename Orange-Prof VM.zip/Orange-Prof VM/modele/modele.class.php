<?php
	class Modele {
		private $unPDO ;
		private $unModele ;  
		public function __construct (){
			try {
				$url="mysql:host=localhost;dbname=orange_efrei";
				$user="paul";
				$mdp="paul";
				$this->unPDO= new PDO ($url, $user, $mdp);
			}
			catch(PDOException $exp){
				echo "Erreur de connexion: ".$exp->getMessage();
			}
		}
		/************* Gestion des clients ***************/
		public function insertClient ($tab){
			$requete = "insert into client values (null, :nom, :prenom,:adresse,:email); "; 
			$donnees = array(
						":nom"=>$tab['nom'], 
						":prenom"=>$tab['prenom'],
						":adresse"=>$tab['adresse'],
						":email"=>$tab['email']
							);
			$insert = $this->unPDO->prepare ($requete); 
			$insert->execute ($donnees);
		}
		public function selectAllClients (){
			$requete ="select * from client ;";
			$select = $this->unPDO->prepare ($requete); 
			$select->execute (); 
			return $select->fetchAll(); 
		}

		public function selectLikeClients ($filtre){
			$requete ="select * from client where nom like :filtre or prenom like :filtre or adresse like :filtre or email like :filtre;";
			$donnees=array(":filtre"=>"%".$filtre."%");
			$select = $this->unPDO->prepare ($requete); 
			$select->execute ($donnees); 
			return $select->fetchAll();

		}

		public function deleteClient($idclient){
			$requete="delete from client where idclient = :idclient;"; 
			$donnees=array(":idclient"=>$idclient);
			$select = $this->unPDO->prepare ($requete); 
			$select->execute ($donnees); 
		}
		public function selectWhereClient($idclient){
			$requete="select * from client where idclient=:idclient;"; 
			$donnees=array(":idclient"=>$idclient);
			$select = $this->unPDO->prepare ($requete); 
			$select->execute ($donnees);
			return $select->fetch() ; 
		}

		public function updateClient($tab){
			$requete="update client set nom=:nom, prenom= :prenom, adresse=:adresse, email=:email where idclient = :idclient;"; 
			$donnees = array(
						":nom"=>$tab['nom'], 
						":prenom"=>$tab['prenom'],
						":adresse"=>$tab['adresse'],
						":email"=>$tab['email'], 
						":idclient"=>$tab['idclient']
							);
			$update = $this->unPDO->prepare ($requete); 
			$update->execute ($donnees);
		}
		public function selectProduitsClients($idclient){
			$requete ="select * from produit where idclient = :idclient;";
			$donnees=array(":idclient"=>$idclient);
			$select = $this->unPDO->prepare ($requete); 
			$select->execute ($donnees);
			return $select->fetchAll(); 
		}
		public function selectCompteClient(){
			$requete ="select * from client where compte = :compte;";
			$donnees=array(":compte"=>$_SESSION['iduser']);
			$select = $this->unPDO->prepare ($requete); 
			$select->execute ($donnees);
			return $select->fetchAll(); 
		}
		public function selectCompteClient2(){
			$requete ="select * from client where compte = :compte;";
			$donnees=array(":compte"=>$_SESSION['iduser']);
			$select = $this->unPDO->prepare ($requete); 
			$select->execute ($donnees);
			return $select->fetch(); 
		}
		/************* Gestion des techniciens ***************/
		public function insertTechnicien ($tab){
			$requete = "insert into technicien values (null, :nom, :prenom,:specialite,:dateEmbauche, null); "; 
			$donnees = array(
						":nom"=>$tab['nom'], 
						":prenom"=>$tab['prenom'],
						":specialite"=>$tab['specialite'],
						":dateEmbauche"=>$tab['dateEmbauche']
							);
			$insert = $this->unPDO->prepare ($requete); 
			$insert->execute ($donnees);
		}
		public function selectAllTechniciens (){
			$requete ="select * from technicien ;";
			$select = $this->unPDO->prepare ($requete); 
			$select->execute (); 
			return $select->fetchAll(); 
		}
		public function selectInterventionsTechniciens($idtechnicien){
			$requete ="select * from intervention where idtechnicien = :idtechnicien;";
			$donnees=array(":idtechnicien"=>$idtechnicien);
			$select = $this->unPDO->prepare ($requete); 
			$select->execute ($donnees);
			return $select->fetchAll(); 
		}
		public function selectWhereTechnicien($idtechnicien){
			$requete="select * from technicien where idtechnicien=:idtechnicien;"; 
			$donnees=array(":idtechnicien"=>$idtechnicien);
			$select = $this->unPDO->prepare ($requete); 
			$select->execute ($donnees);
			return $select->fetch() ; 
		}
		public function updateTechnicien($tab){
			$requete="update technicien set nom=:nom, prenom= :prenom, specialite=:specialite, dateEmbauche=:dateEmbauche where idtechnicien = :idtechnicien;"; 
			$donnees = array(
						":nom"=>$tab['nom'], 
						":prenom"=>$tab['prenom'],
						":specialite"=>$tab['specialite'],
						":dateEmbauche"=>$tab['dateEmbauche'], 
						":idtechnicien"=>$tab['idtechnicien']
							);
			$update = $this->unPDO->prepare ($requete); 
			$update->execute ($donnees);
		}
		public function deleteTechnicien($idtechnicien){
			$requete="delete from technicien where idtechnicien = :idtechnicien;"; 
			$donnees=array(":idtechnicien"=>$idtechnicien);
			$select = $this->unPDO->prepare ($requete); 
			$select->execute ($donnees); 
		}
		public function selectLikeTechniciens ($filtre){
			$requete ="select * from technicien where nom like :filtre or prenom like :filtre or specialite like :filtre or dateEmbauche like :filtre;";
			$donnees=array(":filtre"=>"%".$filtre."%");
			$select = $this->unPDO->prepare ($requete); 
			$select->execute ($donnees); 
			return $select->fetchAll(); 
		} 
		public function selectCompteTechnicien(){
			$requete ="select * from technicien where compte = :compte;";
			$donnees=array(":compte"=>$_SESSION['iduser']);
			$select = $this->unPDO->prepare ($requete); 
			$select->execute ($donnees);
			return $select->fetchAll(); 
		}
		public function selectTechniciens (){
			$requete ="select * from technicien WHERE compte!=:compte OR compte IS NULL;";
			$donnees=array(":compte"=>$_SESSION['iduser']);
			$select = $this->unPDO->prepare ($requete); 
			$select->execute ($donnees);
			return $select->fetchAll(); 
		}
		/********** Gestion des Produits ***************/
		public function insertProduit ($tab){
			$requete = "insert into produit values (null, :designation, :prixAchat, :dateAchat, :categorie, :idclient); "; 
			$donnees = array(
						":designation"=>$tab['designation'], 
						":prixAchat"=>$tab['prixAchat'],
						":dateAchat"=>$tab['dateAchat'],
						":categorie"=>$tab['categorie'],
						":idclient"=>$tab['idclient']
							);
			$insert = $this->unPDO->prepare ($requete); 
			$insert->execute ($donnees);
		}
		public function selectAllProduits (){
			$requete ="select * from produit ;";
			$select = $this->unPDO->prepare ($requete); 
			$select->execute (); 
			return $select->fetchAll(); 
		}
		public function selectClientsProduits($idproduit){
			//$requete ="select client.idclient, nom, prenom, adresse, email from client Join produit ON client.idclient=produit.idclient where idproduit = :idproduit;";
			$requete ="select * from client Join produit ON client.idclient=produit.idclient where idproduit = :idproduit;";
			$donnees=array(":idproduit"=>$idproduit);
			$select = $this->unPDO->prepare ($requete); 
			$select->execute ($donnees);
			return $select->fetchAll(); 
		}
		public function selectWhereProduit($idproduit){
			$requete="select * from produit where idproduit=:idproduit;"; 
			$donnees=array(":idproduit"=>$idproduit);
			$select = $this->unPDO->prepare ($requete); 
			$select->execute ($donnees);
			return $select->fetch() ; 
		}
		public function updateProduit($tab){
			$requete="update produit set designation=:designation, prixAchat= :prixAchat, dateAchat=:dateAchat, categorie=:categorie, idclient=:idclient where idproduit = :idproduit;"; 
			$donnees = array(
						":designation"=>$tab['designation'], 
						":prixAchat"=>$tab['prixAchat'],
						":dateAchat"=>$tab['dateAchat'],
						":categorie"=>$tab['categorie'], 
						":idclient"=>$tab['idclient'],
						"idproduit"=>$tab['idproduit']
							);
			$update = $this->unPDO->prepare ($requete); 
			$update->execute ($donnees);
		}
		public function deleteProduit($idproduit){
			$requete="delete from produit where idproduit = :idproduit;"; 
			$donnees=array(":idproduit"=>$idproduit);
			$select = $this->unPDO->prepare ($requete); 
			$select->execute ($donnees); 
		}
		public function selectLikeProduits ($filtre){
			$requete ="select * from produit where designation like :filtre or prixAchat like :filtre or dateAchat like :filtre or categorie like :filtre or idclient like :filtre;";
			$donnees=array(":filtre"=>"%".$filtre."%");
			$select = $this->unPDO->prepare ($requete); 
			$select->execute ($donnees); 
			return $select->fetchAll(); 
		}
		public function selectLikeProduits2 ($filtre){
			$requete ="select * from produit where (designation like :filtre or prixAchat like :filtre or dateAchat like :filtre or categorie like :filtre) and idclient= :compte;";
			$donnees=array(":filtre"=>"%".$filtre."%", ":compte"=>$_SESSION['iduser']);
			$select = $this->unPDO->prepare ($requete); 
			$select->execute ($donnees); 
			return $select->fetchAll(); 
		}
		public function selectProduitCompteClient(){
			$requete ="select * from produit NATURAL JOIN client where client.compte = :compte;";
			$donnees=array(":compte"=>$_SESSION['iduser']);
			$select = $this->unPDO->prepare ($requete); 
			$select->execute ($donnees);
			return $select->fetchAll(); 
		}
		public function insertProduitCompte ($tab){
			$requete = "insert into produit values (null, :designation, :prixAchat, :dateAchat, :categorie, (SELECT idclient FROM client WHERE compte= :compte)); "; 
			$donnees = array(
						":designation"=>$tab['designation'], 
						":prixAchat"=>$tab['prixAchat'],
						":dateAchat"=>$tab['dateAchat'],
						":categorie"=>$tab['categorie'],
						":compte"=>$_SESSION['iduser']
							);
			$insert = $this->unPDO->prepare ($requete); 
			$insert->execute ($donnees);
		}
		public function updateProduitCompte($tab){
			$requete="update produit set designation=:designation, prixAchat= :prixAchat, dateAchat=:dateAchat, categorie=:categorie, idclient=:compte where idproduit = :idproduit;"; 
			$donnees = array(
						":designation"=>$tab['designation'], 
						":prixAchat"=>$tab['prixAchat'],
						":dateAchat"=>$tab['dateAchat'],
						":categorie"=>$tab['categorie'], 
						":compte"=>$_SESSION['iduser'],
						"idproduit"=>$tab['idproduit']
							);
			$update = $this->unPDO->prepare ($requete); 
			$update->execute ($donnees);
		}
		/********** Gestion des Interventions ***************/
		public function selectAllInterventions (){
			$requete ="select * from  intervention;";
			$select = $this->unPDO->prepare ($requete); 
			$select->execute (); 
			return $select->fetchAll(); 
		}
		public function insertIntervention ($tab){
			$requete = "insert into intervention values (null, :description, :prixInter, :dateInter, :idproduit, :idtechnicien); "; 
			$donnees = array(
						":description"=>$tab['description'], 
						":prixInter"=>$tab['prixInter'],
						":dateInter"=>$tab['dateInter'],
						":idproduit"=>$tab['idproduit'],
						":idtechnicien"=>$tab['idtechnicien']
						);
			$insert = $this->unPDO->prepare ($requete); 
			$insert->execute ($donnees);
		}
		public function selectProduitsInter($idinter){
			$requete ="select * from produit natural join intervention where idinter = :idinter;";
			$donnees=array(":idinter"=>$idinter);
			$select = $this->unPDO->prepare ($requete); 
			$select->execute ($donnees);
			return $select->fetchAll(); 
		}
		public function selectTechniciensInter($idinter){
			$requete ="select * from technicien natural join intervention where idinter = :idinter;";
			$donnees=array(":idinter"=>$idinter);
			$select = $this->unPDO->prepare ($requete); 
			$select->execute ($donnees);
			return $select->fetchAll(); 
		}
		public function selectWhereIntervention($idinter){
			$requete="select * from intervention where idinter=:idinter;"; 
			$donnees=array(":idinter"=>$idinter);
			$select = $this->unPDO->prepare ($requete); 
			$select->execute ($donnees);
			return $select->fetch() ; 
		}
		public function updateIntervention($tab){
			$requete="update intervention set description=:description, prixInter= :prixInter, dateInter=:dateInter, idproduit=:idproduit, idtechnicien=:idtechnicien where idinter = :idinter;"; 
			$donnees = array(
						":description"=>$tab['description'], 
						":prixInter"=>$tab['prixInter'],
						":dateInter"=>$tab['dateInter'],
						":idproduit"=>$tab['idproduit'], 
						"idtechnicien"=>$tab['idtechnicien'],
						":idinter"=>$tab['idinter']
							);
			$update = $this->unPDO->prepare ($requete); 
			$update->execute ($donnees);
		}
		public function deleteIntervention($idinter){
			$requete="delete from intervention where idinter = :idinter;"; 
			$donnees=array(":idinter"=>$idinter);
			$select = $this->unPDO->prepare ($requete); 
			$select->execute ($donnees); 
		}
		public function selectLikeInterventions ($filtre){
			$requete ="select * from intervention where description like :filtre or prixInter like :filtre or dateInter like :filtre or idproduit like :filtre or idtechnicien like :filtre;";
			$donnees=array(":filtre"=>"%".$filtre."%");
			$select = $this->unPDO->prepare ($requete); 
			$select->execute ($donnees); 
			return $select->fetchAll(); 
		}
		public function selectCompteInter(){
			$requete ="select * from intervention NATURAL JOIN produit NATURAL JOIN  client where client.compte = :compte;";
			$donnees=array(":compte"=>$_SESSION['iduser']);
			$select = $this->unPDO->prepare ($requete); 
			$select->execute ($donnees);
			return $select->fetchAll(); 
		}
		public function selectCompteIntervention(){
			$requete ="select * from intervention WHERE idtechnicien IN (SELECT idtechnicien FROM technicien WHERE compte=:compte);";
			$donnees=array(":compte"=>$_SESSION['iduser']);
			$select = $this->unPDO->prepare ($requete); 
			$select->execute ($donnees);
			return $select->fetchAll(); 
		}
		public function selectInterventions (){
			$requete ="select * from intervention NATURAL JOIN technicien where compte!=:compte OR compte IS NULL;";
			$donnees=array(":compte"=>$_SESSION['iduser']);
			$select = $this->unPDO->prepare ($requete); 
			$select->execute ($donnees);
			return $select->fetchAll(); 
		}
		public function monInter ($idinter){
			$requete =" SELECT idtechnicien from intervention where idinter=". $idinter . ";";
			//$donnees=array(":compte"=>$_SESSION['iduser']);
			$select = $this->unPDO->prepare ($requete); 
			$select->execute ();
			return $select->fetch();
		}
		/********** Autres ***************/
		public function count($table){
			$requete="select count(*) as nb from ".$table; 
			$select = $this->unPDO->prepare ($requete); 
			$select->execute ();
			return $select->fetch();
		}
		public function verifConnexion($email, $mdp){
			$requete ="select * from user where email =:email and mdp = :mdp;"; 
			$donnees=array(":email"=>$email, ":mdp"=>$mdp); 
			$select = $this->unPDO->prepare ($requete); 
			$select->execute ($donnees);
			return $select->fetch();
		}

		public function appelProcedure ($nomP, $tab){
			$chaine = "'".implode("','", $tab)."'"; 
			$requete = "call  ".$nomP."(".$chaine."); ";
			$select = $this->unPDO->prepare ($requete); 
			$select->execute ();
		}
		public function countWithIDClient($table, $id){
			$requete="select count(*) as nb from ".$table. " WHERE idclient=". $id .";"; 
			$select = $this->unPDO->prepare ($requete); 
			$select->execute ();
			return $select->fetch();
		}
		public function countMesProduits(){
			$requete="select count(*) as nb from produit WHERE idclient= (SELECT idclient FROM client WHERE compte=:compte);";
			$donnees=array(":compte"=>$_SESSION['iduser']);
			$select = $this->unPDO->prepare ($requete); 
			$select->execute ($donnees);
			return $select->fetch(); 
		}
		public function countWithIDTechnicien($table, $id){
			$requete="select count(*) as nb from ".$table. " WHERE idtechnicien=". $id .";"; 
			$select = $this->unPDO->prepare ($requete); 
			$select->execute ();
			return $select->fetch();
		}
		public function countMesInterventions(){
			$requete="select count(*) as nb from intervention WHERE idproduit IN (SELECT idproduit FROM produit WHERE idclient IN (SELECT idclient FROM client WHERE compte=:compte));";
			$donnees=array(":compte"=>$_SESSION['iduser']);
			$select = $this->unPDO->prepare ($requete); 
			$select->execute ($donnees);
			return $select->fetch(); 
		}
		public function countClientFiltre($filtre){
			$requete="select count(*) as nbClientFiltre from client WHERE nom LIKE '%". $filtre . "%' OR prenom LIKE '%". $filtre . "%' OR adresse LIKE'%". $filtre ."%' OR email LIKE '%". $filtre ."%';"; 
			$select = $this->unPDO->prepare ($requete);
			$select->execute ();
			$result = $select->fetch();
			return $result['nbClientFiltre'];
		}
		public function countProduitFiltre($filtre){
			$requete="select count(*) as nbProduitFiltre from produit WHERE  designation LIKE '%". $filtre . "%' OR prixAchat LIKE '%". $filtre . "%' OR dateAchat LIKE '%". $filtre ."%' OR categorie LIKE '%". $filtre ."%' OR idclient LIKE '%". $filtre . "%';"; 
			$select = $this->unPDO->prepare ($requete); 
			$select->execute ();
			$result = $select->fetch();
			return $result['nbProduitFiltre'];
		}
		public function countProduitFiltre2($filtre){
			$requete="select count(*) as nbProduitFiltre2 from produit WHERE ( designation LIKE '%". $filtre . "%' OR prixAchat LIKE '%". $filtre . "%' OR dateAchat LIKE '%". $filtre ."%' OR categorie LIKE '%". $filtre ."%') AND idclient= ". $_SESSION['iduser'] . " ;"; 
			$donnees=array(":compte"=>$_SESSION['iduser']);
			$select = $this->unPDO->prepare ($requete); 
			$select->execute ();
			$result = $select->fetch();
			return $result['nbProduitFiltre2'];
		}
		public function countTechniFiltre($filtre){
			$requete="select count(*) as nbTechniFiltre from technicien WHERE  nom LIKE '%". $filtre . "%' OR prenom LIKE '%". $filtre . "%' OR specialite LIKE '%". $filtre ."%' OR dateEmbauche LIKE '%". $filtre ."%';"; 
			$select = $this->unPDO->prepare ($requete); 
			$select->execute ();
			$result = $select->fetch();
			return $result['nbTechniFiltre'];
		}
		public function countInterFiltre($filtre){
			$requete="select count(*) as nbInterFiltre from intervention WHERE  description LIKE '%". $filtre . "%' OR prixInter LIKE '%". $filtre . "%' OR dateInter LIKE '%". $filtre ."%' OR idproduit LIKE '%". $filtre ."%' OR idtechnicien LIKE '%". $filtre . "%';"; 
			$select = $this->unPDO->prepare ($requete); 
			$select->execute ();
			$result = $select->fetch();
			return $result['nbInterFiltre'];
		}
	}
?>






