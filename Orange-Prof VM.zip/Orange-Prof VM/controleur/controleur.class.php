<?php
	require_once ("modele/modele.class.php"); 
	class Controleur{
		private $unModele ; 

		public function __construct (){
			$this->unModele = new Modele (); 
		}

		/************ Gestion des clients ***********/
		public function insertClient ($tab){
			//on controle les données : vides 
			$this->unModele->insertClient ($tab);
		}
		public function selectAllClients (){
			return $this->unModele->selectAllClients(); 
		}
		public function selectLikeClients ($filtre){
			return $this->unModele->selectLikeClients($filtre);
		}
		public function deleteClient($idclient){
			$this->unModele->deleteClient($idclient);
		}
		public function selectWhereClient($idclient){
			return $this->unModele->selectWhereClient($idclient); 
		}
		public function updateClient($tab){
			$this->unModele->updateClient($tab); 
		}
		public function selectProduitsClients($idclient)
		{
			return $this->unModele->selectProduitsClients($idclient);
		}
		public function selectCompteClient()
		{
			return $this->unModele->selectCompteClient();
		}
		public function selectCompteClient2()
		{
			return $this->unModele->selectCompteClient2();
		}
		/************ Gestion des techniciens ***********/
		public function insertTechnicien ($tab){
			//on controle les données : vides 
			$this->unModele->insertTechnicien ($tab);
		}
		public function selectAllTechniciens (){
			return $this->unModele->selectAllTechniciens(); 
		}
		public function selectInterventionsTechniciens($idtechnicien)
		{
			return $this->unModele->selectInterventionsTechniciens($idtechnicien);
		}
		public function selectWhereTechnicien($idtechnicien){
			return $this->unModele->selectWhereTechnicien($idtechnicien); 
		}
		public function updateTechnicien($tab){
			$this->unModele->updateTechnicien($tab); 
		}
		public function deleteTechnicien($idtechnicien){
			$this->unModele->deleteTechnicien($idtechnicien);
		}
		public function selectLikeTechniciens ($filtre){
			return $this->unModele->selectLikeTechniciens($filtre);
		}
		public function selectCompteTechnicien()
		{
			return $this->unModele->selectCompteTechnicien();
		}
		public function selectTechniciens (){
			return $this->unModele->selectTechniciens(); 
		}
		/************ Gestion des Produits ***********/
		public function insertProduit ($tab){
			//on controle les données : vides 
			$this->unModele->insertProduit ($tab);
		}
		public function selectAllProduits (){
			return $this->unModele->selectAllProduits(); 
		}
		public function selectClientsProduits($idproduit)
		{
			return $this->unModele->selectClientsProduits($idproduit);
		}
		public function deleteProduit($idproduit){
			$this->unModele->deleteProduit($idproduit);
		}
		public function selectWhereProduit($idproduit){
			return $this->unModele->selectWhereProduit($idproduit); 
		}
		public function updateProduit($tab){
			$this->unModele->updateProduit($tab); 
		}
		public function selectLikeProduits ($filtre){
			return $this->unModele->selectLikeProduits($filtre);
		}
		public function selectLikeProduits2 ($filtre){
			return $this->unModele->selectLikeProduits2($filtre);
		}
		public function selectProduitCompteClient()
		{
			return $this->unModele->selectProduitCompteClient();
		}
		public function selectCompteClientID()
		{
			return $this->unModele->selectCompteClient();
		}
		public function insertProduitCompte ($tab){
			//on controle les données : vides 
			$this->unModele->insertProduitCompte ($tab);
		}
		public function updateProduitCompte($tab){
			$this->unModele->updateProduitCompte($tab); 
		}
		/************ Gestion des Interventions ***********/
		public function selectAllInterventions (){
			return $this->unModele->selectAllInterventions(); 
		}
		public function insertIntervention ($tab){
			//on controle les données : vides 
			$this->unModele->insertIntervention ($tab);
		}
		public function selectProduitsInter($idinter)
		{
			return $this->unModele->selectProduitsInter($idinter);
		}
		public function selectTechniciensInter($idinter)
		{
			return $this->unModele->selectTechniciensInter($idinter);
		}
		public function selectWhereIntervention($idinter){
			return $this->unModele->selectWhereIntervention($idinter); 
		}
		public function updateIntervention($tab){
			$this->unModele->updateIntervention($tab); 
		}
		public function deleteIntervention($idinter){
			$this->unModele->deleteIntervention($idinter);
		}
		public function selectLikeInterventions ($filtre){
			return $this->unModele->selectLikeInterventions($filtre);
		}
		public function selectCompteInter()
		{
			return $this->unModele->selectCompteInter();
		}
		public function selectCompteIntervention()
		{
			return $this->unModele->selectCompteIntervention();
		}
		public function selectInterventions (){
			return $this->unModele->selectInterventions(); 
		}
		public function monInter ($idinter){
			return $this->unModele->monInter($idinter); 
		}
		/************ Autres ***********/
		public function count($table){
			return  $this->unModele->count($table);
		}
		public function verifConnexion($email, $mdp){
			//ici : nous vérifions l'email, la compléxité du MDP
			return $this->unModele->verifConnexion($email, $mdp);
		}
		public function appelProcedure ($nomP, $tab){
			$this->unModele->appelProcedure($nomP, $tab);
		}
		public function countWithIDClient($table, $id){
			return  $this->unModele->countWithIDClient($table, $id);
		}
		public function countWithIDTechnicien($table, $id){
			return  $this->unModele->countWithIDTechnicien($table, $id);
		}
		public function countMesProduits(){
			return  $this->unModele->countMesProduits();
		}
		public function countMesInterventions(){
			return  $this->unModele->countMesInterventions();
		}
		public function countClientFiltre($filtre){
			return  $this->unModele->countClientFiltre($filtre);
		} 
		public function countProduitFiltre($filtre){
			return  $this->unModele->countProduitFiltre($filtre);
		}
		public function countProduitFiltre2($filtre){
			return  $this->unModele->countProduitFiltre2($filtre);
		}
		public function countTechniFiltre($filtre){
			return  $this->unModele->countTechniFiltre($filtre);
		}
		public function countInterFiltre($filtre){
			return  $this->unModele->countInterFiltre($filtre);
		}
	}
?>




