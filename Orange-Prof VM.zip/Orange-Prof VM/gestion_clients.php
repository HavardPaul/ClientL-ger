<h2> Gestion des clients </h2>

<?php
if(isset($_SESSION['role']) && $_SESSION['role']=="admin") {
	$leClient = null; 
	if(isset($_GET['action']) && isset($_GET['idclient'])){
		$idclient = $_GET['idclient']; 
		$action = $_GET['action']; 

		switch ($action){
			case "sup" : 
				//$unControleur->deleteClient($idclient) ; 
				$nomP = "deleteClient"; 
				$tab = array($idclient);
				
				$unControleur->appelProcedure($nomP, $tab);
			break; 
			case "edit" : 
				$leClient=$unControleur->selectWhereClient($idclient);  
			break;
			case "voir" :
				$lesProduits=$unControleur->selectProduitsClients($idclient);
				$nbProduit = $unControleur->countWithIDClient("produit", $idclient)['nb'];
			break;  
		}
	}
	require_once ("vue/vue_insert_client.php"); 
	if(isset($_POST['Valider'])){
		//$unControleur->insertClient($_POST);
		//appel de la procédure stockee 
		$nomP = "insertClient"; 
		$tab = array($_POST['nom'], $_POST['prenom'], 
		$_POST['adresse'], $_POST['email']);
		$unControleur->appelProcedure($nomP, $tab);
	}
	if (isset($_POST['Modifier'])){
		$unControleur->updateClient($_POST); 
		header("Location: index.php?page=2");
	}
} //fin if admin
else if(isset($_SESSION['role']) && $_SESSION['role']=="client") { 
	$leClient= null;
	if(isset($_GET['action']) && isset($_GET['idclient'])){
		$idclient = $_GET['idclient']; 
		$action = $_GET['action']; 

		switch ($action){
			case "sup" : 
				//$unControleur->deleteClient($idclient) ; 
				$nomP = "deleteClient"; 
				$tab = array($idclient);			
				$leClient=$unControleur->selectWhereClient($idclient);
				if ($_SESSION['email'] == $leClient['email']){
					echo "<br> Vous êtes sur le point de supprimer votre compte <br> <br>
						<form method='post' > <input type='submit' name='supprimerCompte' value='Supprimer Mon Compte'> </form>
					";
					if (isset($_POST['supprimerCompte'])){
						$unControleur->appelProcedure($nomP, $tab);
						header("Location: index.php?page=6");
					}
				}
				
			break; 
			case "edit" : 
				$leClient=$unControleur->selectWhereClient($idclient);  
			break;
			case "voir" :
				$lesProduits=$unControleur->selectProduitsClients($idclient);
				$nbProduit = $unControleur->countWithIDClient("produit", $idclient)['nb'];

			break;  
		}
	}
	$leClient=$unControleur->selectCompteClient2();
	require_once ("vue/vue_insert_client.php");
	if (isset($_POST['Modifier'])){
		$unControleur->updateClient($_POST); 
		header("Location: index.php?page=2");
	}
}
if(isset($_SESSION['role']) && $_SESSION['role']=="techni") {
	$leClient = null; 
	if(isset($_GET['action']) && isset($_GET['idclient'])){
		$idclient = $_GET['idclient']; 
		$action = $_GET['action']; 

		switch ($action){
			case "sup" : 
				//$unControleur->deleteClient($idclient) ; 
				$nomP = "deleteClient"; 
				$tab = array($idclient);
				$unControleur->appelProcedure($nomP, $tab);
			break; 
			case "edit" : 
				$leClient=$unControleur->selectWhereClient($idclient);  
			break;
			case "voir" :
				$lesProduits=$unControleur->selectProduitsClients($idclient);
				$nbProduit = $unControleur->countWithIDClient("produit", $idclient)['nb'];
			break;  
		}
	}
	require_once ("vue/vue_insert_client.php"); 
	if(isset($_POST['Valider'])){
		//$unControleur->insertClient($_POST);
		//appel de la procédure stockee 
		$nomP = "insertClient"; 
		$tab = array($_POST['nom'], $_POST['prenom'], 
		$_POST['adresse'], $_POST['email']);
		$unControleur->appelProcedure($nomP, $tab);
	}
	if (isset($_POST['Modifier'])){
		$unControleur->updateClient($_POST); 
		header("Location: index.php?page=2");
	}
}
	if(isset($_POST['Filtrer'])){
		$filtre = $_POST['filtre']; 
		$lesClients = $unControleur->selectLikeClients ($filtre); 
		$nbClientFiltre = $unControleur->countClientFiltre($filtre); 
		echo "<br> Nombre de client(s) filtré(s): ".$nbClientFiltre;
	} else if (isset($_SESSION['role']) && $_SESSION['role']=="client") {
		$lesClients=$unControleur->selectCompteClient();
	} elseif (!isset($_POST['Filtrer']) && $_SESSION['role']!="client" ) {
		$lesClients = $unControleur->selectAllClients ();
		$nbClient = $unControleur->count("client")['nb']; 
		echo "<br> Nombre de clients total: ".$nbClient; 
	}
	require_once ("vue/vue_select_clients.php");

	if (isset($nbProduit)){
		echo "<br> Nombre de produits : ".$nbProduit;
	}
	if (isset($lesProduits)){
		require_once("vue/vue_select_produits.php");
	} 
	
?>