<h2> Gestion des produits </h2>
<?php
if(isset($_SESSION['role']) && $_SESSION['role']=="admin") {
	$leProduit = null; 
	if(isset($_GET['action']) && isset($_GET['idproduit'])){
		$idproduit = $_GET['idproduit']; 
		$action = $_GET['action']; 
		switch ($action){
			case "sup" : 
				$unControleur->deleteProduit($idproduit);
			break; 
			case "edit" : 
				$leProduit=$unControleur->selectWhereProduit($idproduit);  
			break;
			case "voir" :
				$lesClients2=$unControleur->selectClientsProduits($idproduit);
			break;  
		}
	}
	$lesClients = $unControleur->selectAllClients(); 
	require_once ("vue/vue_insert_produit.php"); 
	if (isset($_POST['Valider'])){
		$unControleur->insertProduit($_POST);
	}
	if (isset($_POST['Modifier'])){
		$unControleur->updateProduit($_POST); 
		header("Location: index.php?page=3");
	}
}
if(isset($_SESSION['role']) && $_SESSION['role']=="client") {
	$leProduit = null; 
	if(isset($_GET['action']) && isset($_GET['idproduit'])){
		$idproduit = $_GET['idproduit']; 
		$action = $_GET['action']; 
		switch ($action){
			case "sup" : 
				$unControleur->deleteProduit($idproduit);
			break; 
			case "edit" : 
				$leProduit=$unControleur->selectWhereProduit($idproduit);  
			break;
			case "voir" :
				$lesClients2=$unControleur->selectClientsProduits($idproduit);
			break;  
		}
	}
	$lesClients = $unControleur->selectAllClients(); 
	require_once ("vue/vue_insert_produit.php"); 
	if (isset($_POST['Valider'])){
		$unControleur->insertProduitCompte($_POST);
	}
	if (isset($_POST['Modifier'])){
		$unControleur->updateProduitCompte($_POST); 
		header("Location: index.php?page=3");
	}
}
if(isset($_SESSION['role']) && $_SESSION['role']=="techni") {
	$leProduit = null; 
	if(isset($_GET['action']) && isset($_GET['idproduit'])){
		$idproduit = $_GET['idproduit']; 
		$action = $_GET['action']; 
		switch ($action){
			case "sup" : 
				$unControleur->deleteProduit($idproduit);
			break; 
			case "edit" : 
				$leProduit=$unControleur->selectWhereProduit($idproduit);  
			break;
			case "voir" :
				$lesClients2=$unControleur->selectClientsProduits($idproduit);
			break;  
		}
	}
	$lesClients = $unControleur->selectAllClients(); 
	require_once ("vue/vue_insert_produit.php"); 
	if (isset($_POST['Valider'])){
		$unControleur->insertProduit($_POST);
	}
	if (isset($_POST['Modifier'])){
		$unControleur->updateProduit($_POST); 
		header("Location: index.php?page=3");
	}
}
//$lesProduits = $unControleur->selectAllProduits(); 
if(isset($_POST['Filtrer']) && $_SESSION['role']!="client"){
	$filtre = $_POST['filtre']; 
	$lesProduits = $unControleur->selectLikeProduits ($filtre);
	$nbProduitFiltre = $unControleur->countProduitFiltre($filtre); 
	echo "<br> Nombre de produit(s) filtré(s): ".$nbProduitFiltre; 
} else if (!isset($_POST['Filtrer']) && isset($_SESSION['role']) && $_SESSION['role']=="client") {
	$lesProduits=$unControleur->selectProduitCompteClient();
	$nbProduit = $unControleur->countMesProduits();
	$nb=$nbProduit["nb"];
	echo "<br> Nombre de produits total : ". $nb;
} elseif (!isset($_POST['Filtrer']) && $_SESSION['role']!="client" ) {
	$lesProduits = $unControleur->selectAllProduits ();
	$nb = $unControleur->count("produit")['nb']; 
	echo "<br> Nombre de produits total : ".$nb; 
} elseif (isset($_POST['Filtrer']) && $_SESSION['role']=="client" ) {
	$filtre = $_POST['filtre']; 
	$lesProduits = $unControleur->selectLikeProduits2 ($filtre);
	$nbProduitFiltre2 = $unControleur->countProduitFiltre2($filtre); 
	echo "<br> Nombre de produit(s) filtré(s): ".$nbProduitFiltre2; 
}
require_once ("vue/vue_select_produits.php");
if (isset($lesClients2)){
	require_once("vue/vue_select_clients.php");
}
?>