<?php
if(isset($_SESSION['role']) && $_SESSION['role']=="techni"){
		echo "<h3> Modification technicien </h3>";
	} else {
		echo "<h3> Ajout d'un technicien </h3>";
	}
?>
<form method="post">
	<table>
		<tr>
			<td> Nom Technicien </td>
			<td><input type="text" name="nom"
			value="<?= ($leTechnicien!=null) ? $leTechnicien['nom'] : '' ?>"
			></td>
		</tr>

		<tr>
			<td> Prénom Technicien </td>
			<td><input type="text" name="prenom"
			value="<?= ($leTechnicien!=null) ? $leTechnicien['prenom'] : '' ?>"
			></td>
		</tr>

		<tr>
			<td> Spécialité </td>
			<td><input type="text" name="specialite"
			value="<?= ($leTechnicien!=null) ? $leTechnicien['specialite'] : '' ?>"
			></td>
		</tr>

		<tr>
			<td> Date Embauche </td>
			<td><input type="date" name="dateEmbauche"
			value="<?= ($leTechnicien!=null) ? $leTechnicien['dateEmbauche'] : '' ?>"
			></td>
		</tr>
		<tr>
			<td> </td>
			<td>
				<input type="reset" name="Annuler" value="Annuler">
				<input type="submit"
				<?= ($leTechnicien!=null) ? ' name="Modifier" value="Modifier" ' : '
				name="Valider" value="Valider" ' ?>>
			</td>
		</tr>
		<?= ($leTechnicien!=null) ? '<input type="hidden" name="idtechnicien" value="'.$leTechnicien['idtechnicien'].'">':'' ?>
	</table>
</form>