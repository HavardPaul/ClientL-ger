<h3> Liste des produits </h3>
<form method="post"> 
	Filtrer par : <input type="text" name="filtre">
	<input type="submit" name="Filtrer" value="Filtrer">
</form>
<br>
<table border="1">
	<tr>
		<td> Id Produit </td>
		<td> Désignation  </td>
		<td> Prix d'achat </td>
		<td> Date d'achat </td>
		<td> Catégorie </td>
		<td> Id Client </td> 
		<?php
			if(isset($_SESSION['role']) && $_SESSION['role']=="admin") { 
				echo "<td> Opérations </td>"; 
			} else if(isset($_SESSION['role']) && $_SESSION['role']=="client") { 
				echo "<td> Opérations </td>"; 
			}else if(isset($_SESSION['role']) && $_SESSION['role']=="techni") { 
				echo "<td> Opérations </td>"; 
			}
		?>
	</tr>

	<?php
	if (isset($lesProduits) && !isset($lesProduits2)){
		foreach ($lesProduits as $unProduit) {
			echo "<tr>"; 
			echo "<td>".$unProduit['idproduit']."</td>"; 
			echo "<td>".$unProduit['designation']."</td>";
			echo "<td>".$unProduit['prixAchat']."</td>";
			echo "<td>".$unProduit['dateAchat']."</td>";
			echo "<td>".$unProduit['categorie']."</td>";
			echo "<td>".$unProduit['idclient']."</td>"; 
			if(isset($_SESSION['role']) && $_SESSION['role']=="admin") {
				echo "<td>"; 
				echo "<a href='index.php?page=3&action=sup&idproduit=".$unProduit['idproduit']."'><img src='images/supprimer.png' height='30' width='30'></a>"; 
				echo "<a href='index.php?page=3&action=edit&idproduit=".$unProduit['idproduit']."'><img src='images/editer.png' height='30' width='30'></a>"; 
				echo "<a href='index.php?page=3&action=voir&idproduit=".$unProduit['idproduit']."'><img src='images/voir.png' height='30' width='30'></a>"; 
				echo "</td>";
			} else if(isset($_SESSION['role']) && $_SESSION['role']=="client") {
				echo "<td>"; 
				echo "<a href='index.php?page=3&action=sup&idproduit=".$unProduit['idproduit']."'><img src='images/supprimer.png' height='30' width='30'></a>"; 
				echo "<a href='index.php?page=3&action=edit&idproduit=".$unProduit['idproduit']."'><img src='images/editer.png' height='30' width='30'></a>"; 
				echo "<a href='index.php?page=3&action=voir&idproduit=".$unProduit['idproduit']."'><img src='images/voir.png' height='30' width='30'></a>"; 
				echo "</td>";
			} else if(isset($_SESSION['role']) && $_SESSION['role']=="techni") {
				echo "<td>"; 
				echo "<a href='index.php?page=3&action=sup&idproduit=".$unProduit['idproduit']."'><img src='images/supprimer.png' height='30' width='30'></a>"; 
				echo "<a href='index.php?page=3&action=edit&idproduit=".$unProduit['idproduit']."'><img src='images/editer.png' height='30' width='30'></a>"; 
				echo "<a href='index.php?page=3&action=voir&idproduit=".$unProduit['idproduit']."'><img src='images/voir.png' height='30' width='30'></a>"; 
				echo "</td>";
			}
			echo "</tr>"; 
		}
	} elseif (isset($lesProduits2)) {
		foreach ($lesProduits2 as $unProduit) {
			echo "<tr>"; 
			echo "<td>".$unProduit['idproduit']."</td>"; 
			echo "<td>".$unProduit['designation']."</td>";
			echo "<td>".$unProduit['prixAchat']."</td>";
			echo "<td>".$unProduit['dateAchat']."</td>";
			echo "<td>".$unProduit['categorie']."</td>";
			echo "<td>".$unProduit['idclient']."</td>"; 
			if(isset($_SESSION['role']) && $_SESSION['role']=="admin") {
				echo "<td>"; 
				echo "<a href='index.php?page=3&action=sup&idproduit=".$unProduit['idproduit']."'><img src='images/supprimer.png' height='30' width='30'></a>"; 
				echo "<a href='index.php?page=3&action=edit&idproduit=".$unProduit['idproduit']."'><img src='images/editer.png' height='30' width='30'></a>"; 
				echo "<a href='index.php?page=3&action=voir&idproduit=".$unProduit['idproduit']."'><img src='images/voir.png' height='30' width='30'></a>"; 
				echo "</td>";
			} else if(isset($_SESSION['role']) && $_SESSION['role']=="client") {
				echo "<td>"; 
				echo "<a href='index.php?page=3&action=sup&idproduit=".$unProduit['idproduit']."'><img src='images/supprimer.png' height='30' width='30'></a>"; 
				echo "<a href='index.php?page=3&action=edit&idproduit=".$unProduit['idproduit']."'><img src='images/editer.png' height='30' width='30'></a>"; 
				echo "<a href='index.php?page=3&action=voir&idproduit=".$unProduit['idproduit']."'><img src='images/voir.png' height='30' width='30'></a>"; 
				echo "</td>";
			} else if(isset($_SESSION['role']) && $_SESSION['role']=="techni") {
				echo "<td>"; 
				echo "<a href='index.php?page=3&action=sup&idproduit=".$unProduit['idproduit']."'><img src='images/supprimer.png' height='30' width='30'></a>"; 
				echo "<a href='index.php?page=3&action=edit&idproduit=".$unProduit['idproduit']."'><img src='images/editer.png' height='30' width='30'></a>"; 
				echo "<a href='index.php?page=3&action=voir&idproduit=".$unProduit['idproduit']."'><img src='images/voir.png' height='30' width='30'></a>"; 
				echo "</td>";
			}
			echo "</tr>"; 
		}
	}
	?>
</table>