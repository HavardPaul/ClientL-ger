<h3> Liste des techniciens </h3>
<form method="post"> 
	Filtrer par : <input type="text" name="filtre">
	<input type="submit" name="Filtrer" value="Filtrer">
</form>
<br>
<table border="1">
	<tr>
		<td> Id technicien </td>
		<td> Nom technicien </td>
		<td> Prénom technicien </td>
		<td> Spécialité </td>
		<td> Date Embauche </td> 
	<?php
		if(isset($_SESSION['role']) && $_SESSION['role']=="admin") { 
			echo "<td> Opérations </td>"; 
		} elseif(isset($_SESSION['role']) && $_SESSION['role']=="techni") { 
			echo "<td> Opérations </td>"; 
		}
	?>
	</tr>
	<?php
	if (isset($lesTechniciens) && !isset($lesTechniciens2)){
		foreach ($lesTechniciens as $unTechnicien) {
			echo "<tr>"; 
			echo "<td>".$unTechnicien['idtechnicien']."</td>"; 
			echo "<td>".$unTechnicien['nom']."</td>";
			echo "<td>".$unTechnicien['prenom']."</td>";
			echo "<td>".$unTechnicien['specialite']."</td>";
			echo "<td>".$unTechnicien['dateEmbauche']."</td>";
			if(isset($_SESSION['role']) && $_SESSION['role']=="admin") {
				echo "<td>"; 
				echo "<a href='index.php?page=4&action=sup&idtechnicien=".$unTechnicien['idtechnicien']."'><img src='images/supprimer.png' height='30' width='30'></a>"; 
				echo "<a href='index.php?page=4&action=edit&idtechnicien=".$unTechnicien['idtechnicien']."'><img src='images/editer.png' height='30' width='30'></a>"; 
				echo "<a href='index.php?page=4&action=voir&idtechnicien=".$unTechnicien['idtechnicien']."'><img src='images/voir.png' height='30' width='30'></a>"; 
				echo "</td>";
			} elseif (isset($_SESSION['role']) && $_SESSION['role']=="techni") {
				echo "<td>"; 
				echo "<a href='index.php?page=4&action=voir&idtechnicien=".$unTechnicien['idtechnicien']."'><img src='images/voir.png' height='30' width='30'></a>"; 
				echo "</td>";
			}
			echo "</tr>"; 
		}
		
	} elseif (isset($lesTechniciens2)) {
		foreach ($lesTechniciens2 as $unTechnicien) {
			echo "<tr>"; 
			echo "<td>".$unTechnicien['idtechnicien']."</td>"; 
			echo "<td>".$unTechnicien['nom']."</td>";
			echo "<td>".$unTechnicien['prenom']."</td>";
			echo "<td>".$unTechnicien['specialite']."</td>";
			echo "<td>".$unTechnicien['dateEmbauche']."</td>";
			if(isset($_SESSION['role']) && $_SESSION['role']=="admin") {
				echo "<td>"; 
				echo "<a href='index.php?page=4&action=sup&idtechnicien=".$unTechnicien['idtechnicien']."'><img src='images/supprimer.png' height='30' width='30'></a>"; 
				echo "<a href='index.php?page=4&action=edit&idtechnicien=".$unTechnicien['idtechnicien']."'><img src='images/editer.png' height='30' width='30'></a>"; 
				echo "<a href='index.php?page=4&action=voir&idtechnicien=".$unTechnicien['idtechnicien']."'><img src='images/voir.png' height='30' width='30'></a>"; 
			} elseif (isset($_SESSION['role']) && $_SESSION['role']=="techni") {
				echo "<td>"; 
				if (isset($lesTechniciens2)){
					foreach ($lesTechniciens2 as $unCompteTechnicien) {
						if ($lesTechniciens2[0]['compte']==$_SESSION['iduser']){ 
											echo "<a href='index.php?page=4&action=sup&idtechnicien=".$unTechnicien['idtechnicien']."'><img src='images/supprimer.png' height='30' width='30'></a>"; 
											echo "<a href='index.php?page=4&action=edit&idtechnicien=".$unTechnicien['idtechnicien']."'><img src='images/editer.png' height='30' width='30'></a>"; 
						}	
					}
				}
				echo "<a href='index.php?page=4&action=voir&idtechnicien=".$unTechnicien['idtechnicien']."'><img src='images/voir.png' height='30' width='30'></a>"; 
				echo "</td>";
			}
			echo "</tr>"; 
		}

	} elseif(isset($_SESSION['role']) && $_SESSION['role']=="techni" && !isset($lesTechniciens2)){ 
		foreach ($lesTechniciens3 as $unTechnicien) {
			echo "<tr>"; 
			echo "<td>".$unTechnicien['idtechnicien']."</td>"; 
			echo "<td>".$unTechnicien['nom']."</td>";
			echo "<td>".$unTechnicien['prenom']."</td>";
			echo "<td>".$unTechnicien['specialite']."</td>";
			echo "<td>".$unTechnicien['dateEmbauche']."</td>";
			echo "<td>"; 
			echo "<a href='index.php?page=4&action=voir&idtechnicien=".$unTechnicien['idtechnicien']."'><img src='images/voir.png' height='30' width='30'></a>"; 
			echo "</td>";
			echo "</tr>"; 
		}
		foreach ($leCompteTechnicien as $unCompteTechnicien) {
			echo "<tr>"; 
			echo "<td>".$unCompteTechnicien['idtechnicien']."</td>"; 
			echo "<td>".$unCompteTechnicien['nom']."</td>";
			echo "<td>".$unCompteTechnicien['prenom']."</td>";
			echo "<td>".$unCompteTechnicien['specialite']."</td>";
			echo "<td>".$unCompteTechnicien['dateEmbauche']."</td>";
			echo "<td>"; 
			echo "<a href='index.php?page=4&action=sup&idtechnicien=".$unCompteTechnicien['idtechnicien']."'><img src='images/supprimer.png' height='30' width='30'></a>"; 
			echo "<a href='index.php?page=4&action=edit&idtechnicien=".$unCompteTechnicien['idtechnicien']."'><img src='images/editer.png' height='30' width='30'></a>"; 
			echo "<a href='index.php?page=4&action=voir&idtechnicien=".$unCompteTechnicien['idtechnicien']."&compte=".$unCompteTechnicien['compte']."'><img src='images/voir.png' height='30' width='30'></a>"; 
			echo "</td>";
			echo "</tr>"; 
		}
	} /*elseif(isset($_SESSION['role']) && $_SESSION['role']=="techni" && isset($lesTechniciens2)) { 
		foreach ($lesTechniciens2 as $unTechnicien) {
			echo "<tr>"; 
			echo "<td>".$unTechnicien['idtechnicien']."</td>"; 
			echo "<td>".$unTechnicien['nom']."</td>";
			echo "<td>".$unTechnicien['prenom']."</td>";
			echo "<td>".$unTechnicien['specialite']."</td>";
			echo "<td>".$unTechnicien['dateEmbauche']."</td>";
			echo "<td>"; 
			echo "<a href='index.php?page=4&action=voir&idtechnicien=".$unTechnicien['idtechnicien']."'><img src='images/voir.png' height='30' width='30'></a>"; 
			echo "</td>";
			if ($monInter==$_SESSION['iduser']){
				echo "<td>"; 
				echo "<a href='index.php?page=4&action=sup&idtechnicien=".$unTechnicien['idtechnicien']."'><img src='images/supprimer.png' height='30' width='30'></a>"; 
				echo "<a href='index.php?page=4&action=edit&idtechnicien=".$unTechnicien['idtechnicien']."'><img src='images/editer.png' height='30' width='30'></a>"; 
				echo "<a href='index.php?page=4&action=voir&idtechnicien=".$unTechnicien['idtechnicien']."'><img src='images/voir.png' height='30' width='30'></a>"; 
				echo "</td>";
			}
			echo "</tr>"; 
		}
		foreach ($leCompteTechnicien as $unCompteTechnicien) {
			echo "<tr>"; 
			echo "<td>".$unCompteTechnicien['idtechnicien']."</td>"; 
			echo "<td>".$unCompteTechnicien['nom']."</td>";
			echo "<td>".$unCompteTechnicien['prenom']."</td>";
			echo "<td>".$unCompteTechnicien['specialite']."</td>";
			echo "<td>".$unCompteTechnicien['dateEmbauche']."</td>";
			if(isset($_SESSION['role']) && $_SESSION['role']=="techni") {
				echo "<td>"; 
				echo "<a href='index.php?page=4&action=sup&idtechnicien=".$unCompteTechnicien['idtechnicien']."'><img src='images/supprimer.png' height='30' width='30'></a>"; 
				echo "<a href='index.php?page=4&action=edit&idtechnicien=".$unCompteTechnicien['idtechnicien']."'><img src='images/editer.png' height='30' width='30'></a>"; 
				echo "<a href='index.php?page=4&action=voir&idtechnicien=".$unCompteTechnicien['idtechnicien']."'><img src='images/voir.png' height='30' width='30'></a>"; 
				echo "</td>";
			}
			echo "</tr>"; 
		}
	}*/
	?>
</table>