<img src="images/logo.png" height="200" width="200">
<h1> Connexion à l'intranet Orange</h1>
<form method="post">
	<table>
		<tr> 
			<td> Email </td>
			<td> <input type="text" name="email"></td>
		</tr>
		<tr> 
			<td> MDP </td>
			<td> <input type="password" name="mdp"></td>
		</tr>
		<tr> 
			<td>  </td>
			<td> <input type="submit" name="seConnecter" value="Connexion"></td>
		</tr>
	</table>
</form>