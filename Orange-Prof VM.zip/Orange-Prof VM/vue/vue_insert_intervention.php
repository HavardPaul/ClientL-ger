<h3> Ajout d'une intervention </h3>
<form method="post">
	<table>
		<tr>
    		<td> Description </td>
    		<td>
        		<textarea name="description" rows="4" cols="40"><?= ($lIntervention != null) ? $lIntervention['description'] : '' ?></textarea>
    		</td>
		</tr>


		<tr>
			<td> Prix Inter </td>
			<td><input type="text" name="prixInter"
			value="<?= ($lIntervention!=null) ? $lIntervention['prixInter'] : '' ?>"
			></td>
		</tr>

		<tr>
			<td> Date Inter</td>
			<td><input type="date" name="dateInter"
			value="<?= ($lIntervention!=null) ? $lIntervention['dateInter'] : '' ?>"
			></td>
		</tr>

		<tr>
			<td> Produit </td>
			<td>
				<select name="idproduit">
				<?php
					foreach ($lesProduits as $unProduit) {
					echo "<option value='".$unProduit['idproduit']."'>"; 
					$selected = ($lIntervention != null && $lIntervention['idproduit'] == $unProduit['idproduit']) ? 'selected' : '';
                		echo "<option value='".$unProduit['idproduit']."' $selected>"; 
						echo $unProduit['designation']; 
						echo "</option>"; 
					}
					?>	 
				</select>
			</td>
		</tr>
		<tr>
			<td> Technicien </td>
			<td>
				<select name="idtechnicien">
					<?php
					foreach ($lesTechniciens as $unTechnicien) {
					echo "<option value='".$unTechnicien['idtechnicien']."'>"; 
					$selected = ($lIntervention != null && $lIntervention['idtechnicien'] == $unTechnicien['idtechnicien']) ? 'selected' : '';
                		echo "<option value='".$unTechnicien['idtechnicien']."' $selected>"; 
						echo $unTechnicien['nom']; 
						echo "</option>"; 
					}
					?>
				</select>
			</td>
		</tr>

		<tr>
			<td> </td>
			<td>
				<input type="reset" name="Annuler" value="Annuler">
				<input type="submit" <?= ($lIntervention!=null) ? ' name="Modifier" value="Modifier" ' : '
				name="Valider" value="Valider" ' ?>>
			</td>
		</tr>
		<?= ($lIntervention!=null) ? '<input type="hidden" name="idinter" value="'.$lIntervention['idinter'].'">':'' ?>
	</table>
</form>