<h3> Liste des interventions </h3>
<form method="post"> 
	Filtrer par : <input type="text" name="filtre">
	<input type="submit" name="Filtrer" value="Filtrer">
</form>
<br>
<table border="1">
	<tr>
		<td> Id Intervention </td>
		<td> Description  </td>
		<td> Prix Inter </td>
		<td> Date Inter </td>
		<td> Id Produit </td>
		<td> Id Technicien </td> 
		<?php
			if(isset($_SESSION['role']) && $_SESSION['role']=="admin") { 
				echo "<td> Opérations </td>"; 
			} else if(isset($_SESSION['role']) && $_SESSION['role']=="techni") { 
				echo "<td> Opérations </td>"; 
			}
		?>
	</tr>
	<?php
	if (isset($lesInterventions)){
		foreach ($lesInterventions as $uneInter) {
			echo "<tr>"; 
			echo "<td>".$uneInter['idinter']."</td>"; 
			echo "<td>".$uneInter['description']."</td>";
			echo "<td>".$uneInter['prixInter']."</td>";
			echo "<td>".$uneInter['dateInter']."</td>";
			echo "<td>".$uneInter['idproduit']."</td>";
			echo "<td>".$uneInter['idtechnicien']."</td>";
			if(isset($_SESSION['role']) && $_SESSION['role']=="admin") {
				echo "<td>"; 
				echo "<a href='index.php?page=5&action=sup&idinter=".$uneInter['idinter']."'><img src='images/supprimer.png' height='30' width='30'></a>"; 
				echo "<a href='index.php?page=5&action=edit&idinter=".$uneInter['idinter']."'><img src='images/editer.png' height='30' width='30'></a>"; 
				echo "<a href='index.php?page=5&action=voir&idinter=".$uneInter['idinter']."'><img src='images/voir.png' height='30' width='30'></a>"; 
				echo "</td>";
			} elseif (isset($_SESSION['role']) && $_SESSION['role']=="techni") {
				echo "<td>"; 
				echo "<a href='index.php?page=5&action=voir&idinter=".$uneInter['idinter']."'><img src='images/voir.png' height='30' width='30'></a>"; 
				if (isset($compte)) {
					foreach ($leCompteTechnicien as $unCompteTechnicien) {
						if ($compte==$_SESSION['iduser']){ 
							echo "<a href='index.php?page=5&action=sup&idinter=".$uneInter['idinter']."'><img src='images/supprimer.png' height='30' width='30'></a>"; 
							echo "<a href='index.php?page=5&action=edit&idinter=".$uneInter['idinter']."'><img src='images/editer.png' height='30' width='30'></a>"; 
							echo "</td>";
						}
					}
				} else {
					echo "</td>";
				}
			}
		}
	} elseif(isset($_SESSION['role']) && $_SESSION['role']=="techni") { 
		foreach ($lesInterventions2 as $uneInter) {
			echo "<tr>"; 
			echo "<td>".$uneInter['idinter']."</td>"; 
			echo "<td>".$uneInter['description']."</td>";
			echo "<td>".$uneInter['prixInter']."</td>";
			echo "<td>".$uneInter['dateInter']."</td>";
			echo "<td>".$uneInter['idproduit']."</td>";
			echo "<td>".$uneInter['idtechnicien']."</td>";
			echo "<td>"; 
			echo "<a href='index.php?page=5&action=voir&idinter=".$uneInter['idinter']."'><img src='images/voir.png' height='30' width='30'></a>"; 
			echo "</td>";
		} foreach ($leCompteIntervention as $uneInter2) {
			echo "<tr>"; 
			echo "<td>".$uneInter2['idinter']."</td>"; 
			echo "<td>".$uneInter2['description']."</td>";
			echo "<td>".$uneInter2['prixInter']."</td>";
			echo "<td>".$uneInter2['dateInter']."</td>";
			echo "<td>".$uneInter2['idproduit']."</td>";
			echo "<td>".$uneInter2['idtechnicien']."</td>";
			echo "<td>"; 
			echo "<a href='index.php?page=5&action=sup&idinter=".$uneInter2['idinter']."'><img src='images/supprimer.png' height='30' width='30'></a>"; 
			echo "<a href='index.php?page=5&action=edit&idinter=".$uneInter2['idinter']."'><img src='images/editer.png' height='30' width='30'></a>"; 
			echo "<a href='index.php?page=5&action=voir&idinter=".$uneInter2['idinter']."'><img src='images/voir.png' height='30' width='30'></a>"; 
			echo "</td>";
		}
		echo "</tr>";
	}
	?>
</table>