<h3> Ajout d'un produit </h3>
<form method="post">
	<table>
		<tr>
			<td> Désignation </td>
			<td><input type="text" name="designation"
			value="<?= ($leProduit!=null) ? $leProduit['designation'] : '' ?>"
			></td>
		</tr>
		<tr>
			<td> Prix Achat </td>
			<td><input type="text" name="prixAchat"
			value="<?= ($leProduit!=null) ? $leProduit['prixAchat'] : '' ?>"
			></td>
		</tr>
		<tr>
    		<td> Date Achat</td>
    		<td>
        	<input type="date" name="dateAchat"
            value="<?= ($leProduit != null) ? date('Y-m-d', strtotime($leProduit['dateAchat'])) : '' ?>">
    		</td>
		</tr>
		<tr>
			<td> Catégorie</td>
			<td>
				<select name="categorie">
					<option value="Téléphone" <?= ($leProduit != null && $leProduit['categorie'] == 'Téléphone') ? 'selected' : '' ?>>Téléphone</option>
					<option value="Informatique" <?= ($leProduit != null && $leProduit['categorie'] == 'Informatique') ? 'selected' : '' ?>>Informatique</option>
					<option value="Télévision" <?= ($leProduit != null && $leProduit['categorie'] == 'Télévision') ? 'selected' : '' ?>>Télévision</option>
				</select>
			</td>
		</tr>
            	<?php
            	if (isset($_SESSION['role']) && $_SESSION['role']!="client") {
            		echo "<tr>
    				<td> Le Client</td>
    				<td>
        			<select name='idclient'>";
            		foreach ($lesClients as $unClient) {
                		$selected = ($leProduit != null && $leProduit['idclient'] == $unClient['idclient']) ? 'selected' : '';
                		echo "<option value='".$unClient['idclient']."' $selected>"; 
                		echo $unClient['nom']; 
                		echo "</option>"; 
            		}
            		echo "</select>
            		</td>
					</tr>";
            	}
            	?>
    		
		<tr>
			<td> </td>
			<td>
				<input type="reset" name="Annuler" value="Annuler">
				<input type="submit" <?= ($leProduit!=null) ? ' name="Modifier" value="Modifier" ' : '
				name="Valider" value="Valider" ' ?>
				>
			</td>
		</tr>
		<?= ($leProduit!=null) ? '<input type="hidden" name="idproduit" value="'.$leProduit['idproduit'].'">':'' ?>
	</table>
</form>