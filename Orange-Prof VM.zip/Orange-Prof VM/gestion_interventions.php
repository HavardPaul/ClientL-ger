<h2> Gestion des interventions </h2>

<?php
if(isset($_SESSION['role']) && $_SESSION['role']=="admin") {
	$lIntervention = null; 
	if(isset($_GET['action']) && isset($_GET['idinter'])){
		$idinter = $_GET['idinter']; 
		$action = $_GET['action']; 
		switch ($action){
			case "sup" : 
				$unControleur->deleteIntervention($idinter);
			break; 
			case "edit" : 
				$lIntervention=$unControleur->selectWhereIntervention($idinter);  
			break;
			case "voir" :
				$lesProduits2=$unControleur->selectProduitsInter($idinter);
				$lesTechniciens2=$unControleur->selectTechniciensInter($idinter);
				
			break;  
		}
	}
	$lesTechniciens = $unControleur->selectAllTechniciens(); 
	$lesProduits = $unControleur->selectAllProduits (); 
	require_once ("vue/vue_insert_intervention.php"); 
	if(isset($_POST['Valider'])){
	$unControleur->insertIntervention($_POST);
	}
	if (isset($_POST['Modifier'])){
		$unControleur->updateIntervention($_POST); 
		header("Location: index.php?page=5");
	}
}
if(isset($_SESSION['role']) && $_SESSION['role']=="techni") {
	$lIntervention = null; 
	if(isset($_GET['action']) && isset($_GET['idinter'])){
		$idinter = $_GET['idinter']; 
		$action = $_GET['action']; 
		switch ($action){
			case "sup" : 
				$unControleur->deleteIntervention($idinter);
			break; 
			case "edit" : 
				$lIntervention=$unControleur->selectWhereIntervention($idinter);  
			break;
			case "voir" :
				$lesProduits2=$unControleur->selectProduitsInter($idinter);
				$lesTechniciens2=$unControleur->selectTechniciensInter($idinter);
				$monInter=$unControleur->monInter($idinter);
			break;  
		}
	}
	$lesTechniciens = $unControleur->selectAllTechniciens(); 
	$lesProduits = $unControleur->selectAllProduits (); 
	require_once ("vue/vue_insert_intervention.php"); 
	if(isset($_POST['Valider'])){
	$unControleur->insertIntervention($_POST);
	}
	if (isset($_POST['Modifier'])){
		$unControleur->updateIntervention($_POST); 
		header("Location: index.php?page=5");
	}
}
//$lesInterventions = $unControleur->selectAllInterventions(); 
if(isset($_POST['Filtrer'])){
	$filtre = $_POST['filtre']; 
	$lesInterventions = $unControleur->selectLikeInterventions ($filtre); 
	$nbInterFiltre = $unControleur->countInterFiltre($filtre); 
	echo "<br> Nombre d'intervention(s) filtrée(s) : ".$nbInterFiltre;
} else if (isset($_SESSION['role']) && $_SESSION['role']=="client") {
	$lesInterventions=$unControleur->selectCompteInter();
	$nbProduit = $unControleur->countMesInterventions(); 
	$nb=$nbProduit["nb"];
	echo "<br> Nombre d'interventions me concernant: ".$nb; 
} else if (isset($_SESSION['role']) && $_SESSION['role']=="techni") {
		$leCompteIntervention=$unControleur->selectCompteIntervention();
		$lesInterventions2 = $unControleur->selectInterventions ();
		$nb = $unControleur->count("intervention")['nb']; 
		echo "<br> Nombre d'interventions total: ".$nb; 
}else {
	$lesInterventions = $unControleur->selectAllInterventions ();
	$nb = $unControleur->count("intervention")['nb']; 
	echo "<br> Nombre d'interventions total: ".$nb; 
}
require_once ("vue/vue_select_interventions.php"); 
if (isset($lesProduits2)){
	require_once("vue/vue_select_produits.php");
} 
if (isset($lesTechniciens2)){
	require_once("vue/vue_select_techniciens.php");
} 
?>